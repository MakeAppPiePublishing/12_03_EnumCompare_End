// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 12 (Q4 2020) video 02
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn how to add values to enum cases
//  For more code, go to http://bit.ly/AppPieGithub

import Foundation

enum Size:String{
    case small,medium,large
}

Size.small.rawValue

enum Temperature:Int,Comparable{
    static func < (lhs: Temperature, rhs: Temperature) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
    
    case cold
    case roomTemp
    case warm
    case hot
    
    func toString() -> String{
        switch self{
        case .cold:
            return " Ice"
        case .roomTemp:
            return " Room Temperature"
        case .warm:
            return " Warm"
        case .hot:
            return " Hot"
        }
    }
}

Temperature.cold.rawValue

enum Beverage{
    case water(Size,Temperature)
    case juice(String)
    case cocoa(Temperature)
    case espresso(Int)
}

func drinkFormatter(drink:Beverage) -> String{
var drinkName = ""
switch drink{
    case let .water(size,temp):
        drinkName = size.rawValue + temp.toString() + " Water"
    case  .juice(let fruit):
        drinkName = fruit + " Juice"
    case .cocoa(let temp):
        if temp <= .roomTemp{
            drinkName = "Chocolate Milk"
        } else {
            drinkName = "Hot Chocolate"
        }
    case let .espresso(shots):
        drinkName = "\(shots) shot Espresso"
    }
return drinkName
}

drinkFormatter(drink: .cocoa(.hot))
drinkFormatter(drink: .cocoa(.cold))
drinkFormatter(drink: .cocoa(.roomTemp))
drinkFormatter(drink: .water(.medium,.cold))
